"""SQLite database layer — schema creation, inserts, and queries."""

from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_DDL = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  TEXT    NOT NULL,
    ended_at    TEXT,
    notes       TEXT
);

CREATE TABLE IF NOT EXISTS gps_readings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER NOT NULL REFERENCES sessions(id),
    timestamp    TEXT    NOT NULL,
    latitude     REAL    NOT NULL DEFAULT 0,
    longitude    REAL    NOT NULL DEFAULT 0,
    altitude_m   REAL    NOT NULL DEFAULT 0,
    speed_kmh    REAL    NOT NULL DEFAULT 0,
    satellites   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS lidar_readings (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id           INTEGER NOT NULL REFERENCES sessions(id),
    timestamp            TEXT    NOT NULL,
    frame_id             INTEGER NOT NULL DEFAULT 0,
    estimated_distance_m REAL    NOT NULL DEFAULT 0,
    object_detected      INTEGER NOT NULL DEFAULT 0   -- boolean 0/1
);

CREATE TABLE IF NOT EXISTS mmwave_readings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       INTEGER NOT NULL REFERENCES sessions(id),
    timestamp        TEXT    NOT NULL,
    num_objects      INTEGER NOT NULL DEFAULT 0,
    nearest_range_m  REAL    NOT NULL DEFAULT 0,
    velocity_ms      REAL    NOT NULL DEFAULT 0,
    signal_strength  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS thermal_readings (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id        INTEGER NOT NULL REFERENCES sessions(id),
    timestamp         TEXT    NOT NULL,
    frame_id          INTEGER NOT NULL DEFAULT 0,
    ambient_temp_c    REAL    NOT NULL DEFAULT 0,
    min_temp_c        REAL    NOT NULL DEFAULT 0,
    max_temp_c        REAL    NOT NULL DEFAULT 0,
    avg_temp_c        REAL    NOT NULL DEFAULT 0,
    hotspot_detected  INTEGER NOT NULL DEFAULT 0   -- boolean 0/1
);

CREATE TABLE IF NOT EXISTS human_detection_readings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       INTEGER NOT NULL REFERENCES sessions(id),
    timestamp        TEXT    NOT NULL,
    frame_id         INTEGER NOT NULL DEFAULT 0,
    human_count      INTEGER NOT NULL DEFAULT 0,
    avg_confidence   REAL    NOT NULL DEFAULT 0,
    source           TEXT    NOT NULL DEFAULT ''   -- 'yolo' | 'hog' | 'simulated'
);

CREATE INDEX IF NOT EXISTS idx_gps_session     ON gps_readings(session_id);
CREATE INDEX IF NOT EXISTS idx_lidar_session   ON lidar_readings(session_id);
CREATE INDEX IF NOT EXISTS idx_mmwave_session  ON mmwave_readings(session_id);
CREATE INDEX IF NOT EXISTS idx_thermal_session ON thermal_readings(session_id);
CREATE INDEX IF NOT EXISTS idx_human_session   ON human_detection_readings(session_id);
"""


# ---------------------------------------------------------------------------
# Database class
# ---------------------------------------------------------------------------

class Database:
    """Thin wrapper around an SQLite connection."""

    def __init__(self, path: str | Path = "drone_data.db") -> None:
        self.path = Path(path)
        self._conn: sqlite3.Connection | None = None
        self.session_id: int | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Open the database and create schema if needed."""
        with self._lock:
            self._conn = sqlite3.connect(
                self.path,
                check_same_thread=False,
                detect_types=sqlite3.PARSE_DECLTYPES,
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(_DDL)
            self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            if self._conn:
                if self.session_id is not None:
                    now = datetime.now(timezone.utc).isoformat()
                    cur = self._conn.cursor()
                    try:
                        cur.execute(
                            "UPDATE sessions SET ended_at = ? WHERE id = ?",
                            (now, self.session_id),
                        )
                        self._conn.commit()
                    finally:
                        cur.close()
                self._conn.close()
                self._conn = None

    @contextmanager
    def _cursor(self) -> Generator[sqlite3.Cursor, None, None]:
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Database is not connected.")
            cur = self._conn.cursor()
            try:
                yield cur
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise
            finally:
                cur.close()

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def start_session(self, notes: str = "") -> int:
        """Create a new recording session and return its ID."""
        now = datetime.now(timezone.utc).isoformat()
        with self._cursor() as cur:
            cur.execute(
                "INSERT INTO sessions (started_at, notes) VALUES (?, ?)",
                (now, notes),
            )
            self.session_id = cur.lastrowid
        return self.session_id

    def _close_session(self) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._cursor() as cur:
            cur.execute(
                "UPDATE sessions SET ended_at = ? WHERE id = ?",
                (now, self.session_id),
            )

    # ------------------------------------------------------------------
    # Inserts
    # ------------------------------------------------------------------

    def insert(self, sensor_name: str, data: dict[str, Any]) -> None:
        """Route a sensor reading to the correct table."""
        if self.session_id is None:
            return
        name = sensor_name.lower().replace("-", "").replace(" ", "")
        if name == "gps":
            self._insert_gps(data)
        elif name == "lidar":
            self._insert_lidar(data)
        elif name in ("mmwave", "mm-wave", "mmwaveradar"):
            self._insert_mmwave(data)
        elif name in ("thermal", "thermalsensor", "ir"):
            self._insert_thermal(data)
        elif name in ("humandetection", "human"):
            self._insert_human_detection(data)

    def _insert_gps(self, d: dict) -> None:
        with self._cursor() as cur:
            cur.execute(
                """INSERT INTO gps_readings
                   (session_id, timestamp, latitude, longitude,
                    altitude_m, speed_kmh, satellites)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    self.session_id,
                    d.get("timestamp", ""),
                    d.get("latitude", 0),
                    d.get("longitude", 0),
                    d.get("altitude_m", 0),
                    d.get("speed_kmh", 0),
                    d.get("satellites", 0),
                ),
            )

    def _insert_lidar(self, d: dict) -> None:
        with self._cursor() as cur:
            cur.execute(
                """INSERT INTO lidar_readings
                   (session_id, timestamp, frame_id,
                    estimated_distance_m, object_detected)
                   VALUES (?,?,?,?,?)""",
                (
                    self.session_id,
                    d.get("timestamp", ""),
                    d.get("frame_id", 0),
                    d.get("estimated_distance_m", 0),
                    int(d.get("object_detected", False)),
                ),
            )

    def _insert_mmwave(self, d: dict) -> None:
        with self._cursor() as cur:
            cur.execute(
                """INSERT INTO mmwave_readings
                   (session_id, timestamp, num_objects,
                    nearest_range_m, velocity_ms, signal_strength)
                   VALUES (?,?,?,?,?,?)""",
                (
                    self.session_id,
                    d.get("timestamp", ""),
                    d.get("num_objects", 0),
                    d.get("nearest_range_m", 0),
                    d.get("velocity_ms", 0),
                    d.get("signal_strength", 0),
                ),
            )

    def _insert_thermal(self, d: dict) -> None:
        with self._cursor() as cur:
            cur.execute(
                """INSERT INTO thermal_readings
                   (session_id, timestamp, frame_id,
                    ambient_temp_c, min_temp_c, max_temp_c, avg_temp_c, hotspot_detected)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    self.session_id,
                    d.get("timestamp", ""),
                    d.get("frame_id", 0),
                    d.get("ambient_temp_c", 0.0),
                    d.get("min_temp_c", 0.0),
                    d.get("max_temp_c", 0.0),
                    d.get("avg_temp_c", 0.0),
                    int(d.get("hotspot_detected", False)),
                ),
            )

    def _insert_human_detection(self, d: dict) -> None:
        with self._cursor() as cur:
            cur.execute(
                """INSERT INTO human_detection_readings
                   (session_id, timestamp, frame_id, human_count, avg_confidence, source)
                   VALUES (?,?,?,?,?,?)""",
                (
                    self.session_id,
                    d.get("timestamp", ""),
                    d.get("frame_id", 0),
                    d.get("human_count", 0),
                    d.get("avg_confidence", 0.0),
                    d.get("source", ""),
                ),
            )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def count_readings(self) -> dict[str, int]:
        """Return total reading counts for the current session."""
        if self.session_id is None:
            return {"gps": 0, "lidar": 0, "mmwave": 0, "thermal": 0, "human_detection": 0}
        counts = {}
        for table, key in [
            ("gps_readings", "gps"),
            ("lidar_readings", "lidar"),
            ("mmwave_readings", "mmwave"),
            ("thermal_readings", "thermal"),
            ("human_detection_readings", "human_detection"),
        ]:
            with self._cursor() as cur:
                cur.execute(
                    f"SELECT COUNT(*) FROM {table} WHERE session_id = ?",
                    (self.session_id,),
                )
                counts[key] = cur.fetchone()[0]
        return counts

    def fetch_all_for_session(self, session_id: int | None = None) -> dict[str, list]:
        """Fetch all rows for a session (default: current) from all tables."""
        sid = session_id or self.session_id
        if sid is None:
            return {}
        result = {}
        tables = {
            "gps": "gps_readings",
            "lidar": "lidar_readings",
            "mmwave": "mmwave_readings",
            "thermal": "thermal_readings",
            "human_detection": "human_detection_readings",
        }
        for key, table in tables.items():
            with self._cursor() as cur:
                cur.execute(
                    f"SELECT * FROM {table} WHERE session_id = ? ORDER BY timestamp",
                    (sid,),
                )
                result[key] = [dict(row) for row in cur.fetchall()]
        return result

    def ai_session_snapshot(self, recent_limit: int = 20) -> dict[str, Any]:
        """Build a compact, factual snapshot for the local AI assistant.

        Aggregates cover the whole active session, while recent readings give
        the assistant real-time context without sending an unbounded database
        dump to the local model.
        """
        if self.session_id is None:
            return {}

        sid = self.session_id
        tables = {
            "gps": "gps_readings",
            "lidar": "lidar_readings",
            "mmwave": "mmwave_readings",
            "thermal": "thermal_readings",
            "human_detection": "human_detection_readings",
        }
        snapshot: dict[str, Any] = {"session_id": sid, "summary": {}, "recent_readings": {}}

        with self._cursor() as cur:
            cur.execute("SELECT started_at, ended_at, notes FROM sessions WHERE id = ?", (sid,))
            session = cur.fetchone()
            snapshot["session"] = dict(session) if session else {}

        for key, table in tables.items():
            with self._cursor() as cur:
                cur.execute(
                    f"SELECT COUNT(*) AS reading_count, MIN(timestamp) AS first_timestamp, "
                    f"MAX(timestamp) AS last_timestamp FROM {table} WHERE session_id = ?",
                    (sid,),
                )
                snapshot["summary"][key] = dict(cur.fetchone())
                cur.execute(
                    f"SELECT * FROM {table} WHERE session_id = ? "
                    f"ORDER BY timestamp DESC LIMIT ?",
                    (sid, recent_limit),
                )
                snapshot["recent_readings"][key] = [dict(row) for row in cur.fetchall()]

        return snapshot

    def human_detection_summary(self) -> dict[str, Any]:
        """Return exact current and session-wide human-detection facts."""
        if self.session_id is None:
            return {}

        with self._cursor() as cur:
            cur.execute(
                """SELECT timestamp, human_count, avg_confidence, source
                   FROM human_detection_readings
                   WHERE session_id = ?
                   ORDER BY timestamp DESC LIMIT 1""",
                (self.session_id,),
            )
            latest = cur.fetchone()
            cur.execute(
                """SELECT MAX(human_count) AS peak_count,
                          AVG(human_count) AS average_count,
                          SUM(CASE WHEN human_count > 0 THEN 1 ELSE 0 END) AS detected_samples,
                          COUNT(*) AS total_samples
                   FROM human_detection_readings WHERE session_id = ?""",
                (self.session_id,),
            )
            totals = cur.fetchone()

        if latest is None or totals is None:
            return {}
        return {"latest": dict(latest), "totals": dict(totals)}

    def latest_sensor_reading(self, sensor: str) -> dict[str, Any]:
        """Return the newest reading for one sensor in the active session."""
        if self.session_id is None:
            return {}

        tables = {
            "gps": "gps_readings",
            "lidar": "lidar_readings",
            "mmwave": "mmwave_readings",
            "thermal": "thermal_readings",
        }
        table = tables.get(sensor)
        if table is None:
            return {}
        with self._cursor() as cur:
            cur.execute(
                f"SELECT * FROM {table} WHERE session_id = ? ORDER BY timestamp DESC LIMIT 1",
                (self.session_id,),
            )
            row = cur.fetchone()
        return dict(row) if row else {}
