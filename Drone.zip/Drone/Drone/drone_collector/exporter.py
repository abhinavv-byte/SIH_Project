"""CSV export utility."""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from .database import Database


def export_session(db: Database, output_dir: str | Path = ".") -> Path:
    """Export all sensor readings for the current session to a CSV file.

    Merges GPS, LiDAR, mm-Wave, Thermal, and Human Detection readings by
    timestamp into a single flat table. Rows that have no data for a given
    sensor will have empty cells.

    Args:
        db: Open :class:`Database` instance with an active session.
        output_dir: Directory where the CSV file will be written.

    Returns:
        Path of the written CSV file.
    """
    data = db.fetch_all_for_session()
    if not any(data.values()):
        raise ValueError("No data to export for the current session.")

    timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = Path(output_dir) / f"export_{timestamp_str}.csv"

    # Build a unified list of rows keyed by timestamp
    rows: dict[str, dict] = {}

    for reading in data.get("gps", []):
        ts = reading["timestamp"]
        rows.setdefault(ts, {"timestamp": ts})
        rows[ts].update(
            {
                "gps_latitude": reading.get("latitude", ""),
                "gps_longitude": reading.get("longitude", ""),
                "gps_altitude_m": reading.get("altitude_m", ""),
                "gps_speed_kmh": reading.get("speed_kmh", ""),
                "gps_satellites": reading.get("satellites", ""),
            }
        )

    for reading in data.get("lidar", []):
        ts = reading["timestamp"]
        rows.setdefault(ts, {"timestamp": ts})
        rows[ts].update(
            {
                "lidar_frame_id": reading.get("frame_id", ""),
                "lidar_estimated_distance_m": reading.get("estimated_distance_m", ""),
                "lidar_object_detected": reading.get("object_detected", ""),
            }
        )

    for reading in data.get("mmwave", []):
        ts = reading["timestamp"]
        rows.setdefault(ts, {"timestamp": ts})
        rows[ts].update(
            {
                "mmwave_num_objects": reading.get("num_objects", ""),
                "mmwave_nearest_range_m": reading.get("nearest_range_m", ""),
                "mmwave_velocity_ms": reading.get("velocity_ms", ""),
                "mmwave_signal_strength": reading.get("signal_strength", ""),
            }
        )

    for reading in data.get("thermal", []):
        ts = reading["timestamp"]
        rows.setdefault(ts, {"timestamp": ts})
        rows[ts].update(
            {
                "thermal_frame_id": reading.get("frame_id", ""),
                "thermal_ambient_temp_c": reading.get("ambient_temp_c", ""),
                "thermal_min_temp_c": reading.get("min_temp_c", ""),
                "thermal_max_temp_c": reading.get("max_temp_c", ""),
                "thermal_avg_temp_c": reading.get("avg_temp_c", ""),
                "thermal_hotspot_detected": reading.get("hotspot_detected", ""),
            }
        )

    for reading in data.get("human_detection", []):
        ts = reading["timestamp"]
        rows.setdefault(ts, {"timestamp": ts})
        rows[ts].update(
            {
                "human_frame_id": reading.get("frame_id", ""),
                "human_count": reading.get("human_count", ""),
                "human_avg_confidence": reading.get("avg_confidence", ""),
                "human_detection_source": reading.get("source", ""),
            }
        )

    # Sort by timestamp
    sorted_rows = sorted(rows.values(), key=lambda r: r["timestamp"])

    fieldnames = [
        "timestamp",
        "gps_latitude",
        "gps_longitude",
        "gps_altitude_m",
        "gps_speed_kmh",
        "gps_satellites",
        "lidar_frame_id",
        "lidar_estimated_distance_m",
        "lidar_object_detected",
        "mmwave_num_objects",
        "mmwave_nearest_range_m",
        "mmwave_velocity_ms",
        "mmwave_signal_strength",
        "thermal_frame_id",
        "thermal_ambient_temp_c",
        "thermal_min_temp_c",
        "thermal_max_temp_c",
        "thermal_avg_temp_c",
        "thermal_hotspot_detected",
        "human_frame_id",
        "human_count",
        "human_avg_confidence",
        "human_detection_source",
    ]

    with filename.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(sorted_rows)

    return filename