"""OpenCV-based Live Video Feed & HUD Visualizer for Drone Sensors."""

from __future__ import annotations

import math
import random
import threading
import time
from datetime import datetime, timezone
from queue import Queue
from typing import Any, Callable

import cv2
import numpy as np

# YOLO is an optional dependency (pulls in torch) — the app must keep working
# with the HOG fallback if it isn't installed. See pyproject.toml's "yolo"
# extra: `pip install -e ".[yolo]"`.
try:
    from ultralytics import YOLO  # noqa: PLC0415

    _ULTRALYTICS_AVAILABLE = True
except Exception:  # noqa: BLE001
    _ULTRALYTICS_AVAILABLE = False

# COCO class id for "person"
_YOLO_PERSON_CLASS = 0


class LiveFeedVisualizer:
    """Renders a real-time OpenCV HUD feed with sensor telemetry overlays.

    In hardware mode, displays real camera frames.
    In simulation mode, synthesizes a dynamic first-person drone HUD view
    (artificial horizon, approaching obstacles, radar/thermal telemetry overlay).
    """

    def __init__(
        self,
        title: str = "Drone Live Feed & Sensor HUD",
        yolo_model: str = "yolov8n.pt",
        yolo_conf: float = 0.35,
        queue: Queue | None = None,
        frame_provider: Callable[[], np.ndarray | None] | None = None,
    ) -> None:
        self.title = title
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._latest_data: dict[str, Any] = {}
        self._lock = threading.Lock()
        self._frame_counter = 0

        # Human detection state
        self._hog: cv2.HOGDescriptor | None = None
        self._yolo_model_name = yolo_model
        self._yolo_conf = yolo_conf
        self._yolo_model: Any = None
        self._yolo_load_failed = False
        self._backend = "yolo" if _ULTRALYTICS_AVAILABLE else "hog"
        self._backend_logged = False
        self._human_boxes: list[tuple[int, int, int, int, float]] = []
        # YOLO is heavier per-call than HOG, so detect less often to keep
        # the ~30 FPS render loop responsive.
        self._real_detect_every = 5 if self._backend == "yolo" else 3
        self._last_human_count = 0

        # Simulated multi-person walkers: the number of "people" present
        # changes every few seconds so the count is meaningfully variable
        # (0-3) instead of always exactly one.
        self._sim_person_count = 1
        self._sim_count_change_at = time.time() + random.uniform(3.0, 6.0)

        # Persistence: push human-detection readings onto the shared data
        # queue (same one the sensors use) so the writer thread stores them
        # in SQLite and they end up in the CSV export alongside GPS/LiDAR/
        # mm-Wave/Thermal data.
        self._data_queue = queue
        self._frame_provider = frame_provider
        self._db_report_interval = 0.2  # ~5 Hz, matches Thermal's cadence
        self._last_db_report_time = 0.0

        # Thread-safe snapshot of the latest human-detection reading, for
        # the terminal dashboard to read (mirrors BaseSensor.latest).
        self._report_lock = threading.Lock()
        self._latest_report: dict[str, Any] = {}

    @property
    def latest(self) -> dict[str, Any]:
        """Most recent human-detection reading (thread-safe)."""
        with self._report_lock:
            return dict(self._latest_report)

    def start(self) -> None:
        """Start visualizer display thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, name="visualizer-thread", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop visualizer thread and close windows."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2)

    def update_telemetry(self, latest: dict[str, Any], raw_frame: np.ndarray | None = None) -> None:
        """Thread-safe update of latest telemetry and optional camera frame."""
        with self._lock:
            self._latest_data = dict(latest)
            if raw_frame is not None:
                self._latest_data["_raw_frame"] = raw_frame.copy()

    def _run(self) -> None:
        """Main rendering loop running at ~30 FPS."""
        while not self._stop_event.is_set():
            with self._lock:
                telemetry = dict(self._latest_data)

            raw_frame = telemetry.pop("_raw_frame", None)
            if raw_frame is None and self._frame_provider is not None:
                try:
                    raw_frame = self._frame_provider()
                except Exception:  # noqa: BLE001
                    raw_frame = None

            try:
                frame = self._render_frame(telemetry, raw_frame)
            except Exception as exc:  # noqa: BLE001
                # A bad frame/telemetry value must never kill this thread —
                # log it and keep going instead of freezing/crashing the feed.
                print(f"[visualizer] render error: {exc!r}")
                time.sleep(0.03)
                continue

            try:
                cv2.imshow(self.title, frame)
                # cv2.waitKey is needed to process GUI events
                key = cv2.waitKey(30) & 0xFF
                if key == ord("q"):
                    # Window close request
                    break
            except Exception:
                time.sleep(0.03)

        cv2.destroyAllWindows()

    def _render_frame(self, telemetry: dict[str, Any], raw_frame: np.ndarray | None) -> np.ndarray:
        """Draw synthetic drone view or overlay telemetry on real camera frame."""
        self._frame_counter += 1
        w, h = 640, 480

        if raw_frame is not None and isinstance(raw_frame, np.ndarray):
            frame = cv2.resize(raw_frame, (w, h))
            # Normalise to 3-channel BGR — some webcams/drivers hand back
            # grayscale (2-D) or BGRA (4-channel) frames. Every overlay below
            # assumes 3-channel color, so a mismatch here used to crash the
            # whole render (and silently kill the feed thread).
            if frame.ndim == 2:
                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
            elif frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            # Real person detection on actual camera frames (throttled — HOG is
            # relatively expensive, so we don't run it on every single frame).
            # Wrapped defensively: a bad/odd frame must never take the whole
            # feed down, it should just skip detection for this frame.
            try:
                if self._frame_counter % self._real_detect_every == 0:
                    self._human_boxes = self._detect_humans_real(frame)
                self._draw_human_boxes(frame, self._human_boxes)
            except Exception as exc:  # noqa: BLE001
                print(f"[visualizer] human detection error: {exc!r}")
                self._human_boxes = []
        else:
            frame = self._synthesize_drone_view(telemetry, w, h)
            # Simulated walking figure + detection box for the synthetic view.
            self._human_boxes = self._simulate_human_detection(frame, w, h)

        self._last_human_count = len(self._human_boxes)
        source = self._backend if (raw_frame is not None and isinstance(raw_frame, np.ndarray)) else "simulated"
        self._report_human_detection(source)

        # Draw HUD overlays
        self._draw_hud(frame, telemetry, w, h)
        return frame

    def _report_human_detection(self, source: str) -> None:
        """Update the thread-safe `.latest` snapshot and — throttled to
        `_db_report_interval` — push a reading onto the shared data queue so
        it gets persisted to SQLite and merged into the CSV export.
        """
        now = time.time()
        confidences = [b[4] for b in self._human_boxes]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

        reading = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "frame_id": self._frame_counter,
            "human_count": self._last_human_count,
            "avg_confidence": round(avg_confidence, 3),
            "source": source,
        }

        with self._report_lock:
            self._latest_report = reading

        if self._data_queue is not None and now - self._last_db_report_time >= self._db_report_interval:
            self._last_db_report_time = now
            try:
                self._data_queue.put_nowait({"sensor": "HumanDetection", "data": reading})
            except Exception:  # noqa: BLE001
                # Queue full or otherwise unavailable — drop this sample
                # rather than blocking the render loop.
                pass

    # ------------------------------------------------------------------
    # Human detection
    # ------------------------------------------------------------------

    def _get_hog(self) -> cv2.HOGDescriptor:
        """Lazily build the HOG + default people-detector SVM (cached)."""
        if self._hog is None:
            hog = cv2.HOGDescriptor()
            hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
            self._hog = hog
        return self._hog

    def _get_yolo(self) -> Any:
        """Lazily load the YOLO model (cached). Downloads weights on first
        use if not already cached locally by ultralytics."""
        if self._yolo_model is None and not self._yolo_load_failed:
            try:
                self._yolo_model = YOLO(self._yolo_model_name)
            except Exception as exc:  # noqa: BLE001
                print(f"[visualizer] failed to load YOLO model {self._yolo_model_name!r}: {exc!r}")
                self._yolo_load_failed = True
        return self._yolo_model

    def _detect_humans_real(self, frame: np.ndarray) -> list[tuple[int, int, int, int, float]]:
        """Detect people in a real camera frame.

        Prefers YOLO (much better accuracy — handles occlusion, odd poses,
        smaller/farther people) and transparently falls back to the classic
        HOG detector if ultralytics isn't installed or the model fails to
        load, so the feature keeps working either way.
        """
        if self._backend == "yolo":
            if not self._backend_logged:
                print("[visualizer] human detection backend: YOLO")
                self._backend_logged = True
            boxes = self._detect_humans_yolo(frame)
            if self._yolo_load_failed:
                # Model failed to load — permanently drop to HOG for the
                # rest of this session instead of retrying every call.
                self._backend = "hog"
                self._real_detect_every = 3
                print("[visualizer] YOLO unavailable, falling back to HOG detector")
                return self._detect_humans_hog(frame)
            return boxes

        if not self._backend_logged:
            print("[visualizer] human detection backend: HOG (fallback)")
            self._backend_logged = True
        return self._detect_humans_hog(frame)

    def _detect_humans_yolo(self, frame: np.ndarray) -> list[tuple[int, int, int, int, float]]:
        """Run YOLO person detection, filtered to the COCO 'person' class."""
        model = self._get_yolo()
        if model is None:
            return []

        try:
            results = model.predict(
                frame,
                classes=[_YOLO_PERSON_CLASS],
                conf=self._yolo_conf,
                verbose=False,
            )
        except Exception as exc:  # noqa: BLE001
            print(f"[visualizer] YOLO inference error: {exc!r}")
            return []

        boxes = []
        for result in results:
            if result.boxes is None:
                continue
            for box in result.boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                conf = float(box.conf[0])
                boxes.append((int(x1), int(y1), int(x2 - x1), int(y2 - y1), conf))
        return boxes

    def _detect_humans_hog(self, frame: np.ndarray) -> list[tuple[int, int, int, int, float]]:
        """Run classic HOG person detection on a real camera frame.

        Detection is done on a downscaled copy for speed, then boxes are
        rescaled back to the display frame's coordinates. Used as the
        fallback when YOLO/ultralytics isn't available.
        """
        det_w, det_h = 320, 240
        small = cv2.resize(frame, (det_w, det_h))

        # Normalise channel count — some webcams/drivers hand back grayscale
        # (1-channel) or BGRA (4-channel) frames instead of BGR, which would
        # otherwise throw inside cvtColor/equalizeHist below.
        if small.ndim == 2:
            gray = small
        elif small.shape[2] == 4:
            gray = cv2.cvtColor(small, cv2.COLOR_BGRA2GRAY)
        elif small.shape[2] == 3:
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        else:
            return []

        gray = cv2.equalizeHist(gray)
        small_bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

        hog = self._get_hog()
        try:
            rects, weights = hog.detectMultiScale(
                small_bgr, winStride=(8, 8), padding=(8, 8), scale=1.05
            )
        except Exception:  # noqa: BLE001
            return []

        sx, sy = frame.shape[1] / det_w, frame.shape[0] / det_h
        boxes = []
        for (x, y, bw, bh), weight in zip(rects, weights):
            # HOG's raw SVM weight isn't a probability; squash it into a
            # readable 0-1 "confidence" so it's comparable to YOLO's output.
            confidence = max(0.0, min(1.0, (weight + 1.0) / 3.0))
            boxes.append(
                (int(x * sx), int(y * sy), int(bw * sx), int(bh * sy), confidence)
            )
        return boxes

    def _draw_human_boxes(
        self, frame: np.ndarray, boxes: list[tuple[int, int, int, int, float]]
    ) -> None:
        """Draw detection rectangles + confidence labels for detected humans."""
        for x, y, bw, bh, confidence in boxes:
            cv2.rectangle(frame, (x, y), (x + bw, y + bh), (0, 140, 255), 2)
            cv2.putText(
                frame,
                f"HUMAN {confidence * 100:.0f}%",
                (x, max(15, y - 6)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.42,
                (0, 140, 255),
                1,
            )

    def _simulate_human_detection(
        self, frame: np.ndarray, w: int, h: int
    ) -> list[tuple[int, int, int, int, float]]:
        """Draw 0-3 animated stick figures walking through the synthetic
        scene, each with a matching detection box. The number of people
        present changes every few seconds so the detected count is
        meaningfully variable, exercising the same overlay/reporting path
        used in hardware mode.
        """
        now = time.time()
        if now >= self._sim_count_change_at:
            self._sim_person_count = random.randint(0, 3)
            self._sim_count_change_at = now + random.uniform(3.0, 6.0)

        boxes: list[tuple[int, int, int, int, float]] = []
        t_base = self._frame_counter * 0.03

        for i in range(self._sim_person_count):
            # Give each walker its own phase/speed so they don't move in
            # lockstep or perfectly overlap.
            phase = i * 2.4
            speed = 1.0 + 0.15 * i
            t = t_base * speed + phase

            x_norm = (math.sin(t) + 1) / 2  # 0..1
            person_x = int(w * 0.12 + x_norm * w * 0.76)
            ground_y = int(h * 0.64)
            figure_h = 72
            head_r = 7

            head_cy = ground_y - figure_h
            limb_color = (25, 25, 25)

            # Head + torso
            cv2.circle(frame, (person_x, head_cy), head_r, limb_color, -1)
            cv2.line(frame, (person_x, head_cy + head_r), (person_x, ground_y - 18), limb_color, 3)

            # Swinging legs/arms for a simple walk cycle
            leg_swing = int(7 * math.sin(t * 6))
            cv2.line(
                frame, (person_x, ground_y - 18), (person_x - 9 + leg_swing, ground_y), limb_color, 3
            )
            cv2.line(
                frame, (person_x, ground_y - 18), (person_x + 9 - leg_swing, ground_y), limb_color, 3
            )
            arm_swing = int(6 * math.sin(t * 6 + math.pi))
            shoulder_y = head_cy + head_r + 10
            cv2.line(frame, (person_x, shoulder_y), (person_x - 11 + arm_swing, ground_y - 32), limb_color, 2)
            cv2.line(frame, (person_x, shoulder_y), (person_x + 11 - arm_swing, ground_y - 32), limb_color, 2)

            # Ground shadow for a bit of grounding/depth
            cv2.ellipse(
                frame, (person_x, ground_y + 3), (16, 4), 0, 0, 360, (10, 10, 10), -1
            )

            # Detection box around the figure with a wobbling confidence score
            pad = 8
            bx1, by1 = person_x - 13 - pad, head_cy - head_r - pad
            bx2, by2 = person_x + 13 + pad, ground_y + 6
            confidence = 0.80 + 0.15 * abs(math.sin(t * 1.3 + i))

            cv2.rectangle(frame, (bx1, by1), (bx2, by2), (0, 140, 255), 2)
            cv2.putText(
                frame,
                f"HUMAN {confidence * 100:.0f}%",
                (bx1, max(15, by1 - 6)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.42,
                (0, 140, 255),
                1,
            )

            boxes.append((bx1, by1, bx2 - bx1, by2 - by1, confidence))

        return boxes

    def _synthesize_drone_view(self, telemetry: dict[str, Any], w: int, h: int) -> np.ndarray:
        """Generate a synthetic first-person drone camera view for simulation."""
        # Sky and Ground gradient
        frame = np.zeros((h, w, 3), dtype=np.uint8)

        # Gentle roll and pitch simulation
        t = self._frame_counter * 0.05
        roll_angle = math.sin(t * 0.5) * 5.0  # +/- 5 deg
        pitch_offset = int(math.cos(t * 0.3) * 20.0)  # +/- 20 px

        # Sky (dark slate blue)
        frame[0 : h // 2 + pitch_offset, :] = [45, 25, 20]
        # Ground (dark olive green / ground terrain)
        frame[h // 2 + pitch_offset : h, :] = [20, 40, 25]

        # Draw Artificial Horizon Line
        cx, cy = w // 2, h // 2 + pitch_offset
        dx = int(w * 0.4 * math.cos(math.radians(roll_angle)))
        dy = int(w * 0.4 * math.sin(math.radians(roll_angle)))
        cv2.line(frame, (cx - dx, cy - dy), (cx + dx, cy + dy), (0, 255, 255), 1)

        # Draw Pitch Ladders
        for p in (-40, -20, 20, 40):
            ladder_y = cy + p
            if 40 < ladder_y < h - 40:
                cv2.line(frame, (cx - 30, ladder_y), (cx + 30, ladder_y), (0, 200, 200), 1)

        # Draw simulated approaching obstacle if LiDAR/Radar detects one
        lidar = telemetry.get("LiDAR", {})
        dist = lidar.get("estimated_distance_m", 10.0)
        obj_detected = lidar.get("object_detected", False)

        if dist < 15.0:
            # Scale bounding box inversely with distance
            box_size = int(max(20, min(180, (20.0 - dist) * 12)))
            bx = cx - box_size // 2
            by = cy - box_size // 2
            color = (0, 0, 255) if obj_detected else (0, 255, 0)
            cv2.rectangle(frame, (bx, by), (bx + box_size, by + box_size), color, 2)
            cv2.putText(
                frame,
                f"OBSTACLE {dist:.1f}m",
                (bx, max(20, by - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                color,
                1,
            )

        # Reticle / Crosshair in center
        cv2.drawMarker(frame, (w // 2, h // 2), (0, 255, 0), cv2.MARKER_CROSS, 24, 1)
        cv2.circle(frame, (w // 2, h // 2), 12, (0, 255, 0), 1)

        return frame

    def _draw_hud(self, frame: np.ndarray, telemetry: dict[str, Any], w: int, h: int) -> None:
        """Overlay sensor telemetry badges onto frame."""
        gps = telemetry.get("GPS", {})
        lidar = telemetry.get("LiDAR", {})
        mmwave = telemetry.get("mm-Wave", {})
        thermal = telemetry.get("Thermal", {})

        # Top HUD Banner (Dark background bar for readability)
        cv2.rectangle(frame, (0, 0), (w, 35), (0, 0, 0), -1)

        # Top Status: Mode & Time
        cv2.putText(
            frame,
            "DRONE SIM LIVE FEED [RECORDING]",
            (10, 22),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 0),
            1,
        )

        # Human Detection Badge (right side of the top banner bar)
        human_count = self._last_human_count
        hd_color = (0, 140, 255) if human_count > 0 else (0, 255, 0)
        backend_label = "YOLO" if self._backend == "yolo" else "HOG"
        hd_text = (
            f"PERSON DETECT [{backend_label}]: "
            f"{'DETECTED' if human_count else 'CLEAR'} ({human_count})"
        )
        (tw, _), _ = cv2.getTextSize(hd_text, cv2.FONT_HERSHEY_SIMPLEX, 0.48, 1)
        cv2.putText(
            frame,
            hd_text,
            (w - tw - 10, 22),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            hd_color,
            1,
        )

        # GPS Badge (Top-Right)
        lat = gps.get("latitude", 0.0)
        lon = gps.get("longitude", 0.0)
        alt = gps.get("altitude_m", 0.0)
        spd = gps.get("speed_kmh", 0.0)
        sats = gps.get("satellites", 0)
        gps_text = f"GPS: {lat:+.4f}, {lon:+.4f} | ALT: {alt:.1f}m | SPD: {spd:.1f}kph | SATS:{sats}"
        cv2.putText(
            frame,
            gps_text,
            (10, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.4,
            (255, 255, 255),
            1,
        )

        # Bottom Left Overlay: LiDAR & Radar Telemetry
        dist = lidar.get("estimated_distance_m", 0.0)
        radar_objs = mmwave.get("num_objects", 0)
        radar_rng = mmwave.get("nearest_range_m", 0.0)
        radar_vel = mmwave.get("velocity_ms", 0.0)

        cv2.rectangle(frame, (10, h - 90), (240, h - 10), (0, 0, 0), -1)
        cv2.rectangle(frame, (10, h - 90), (240, h - 10), (100, 100, 100), 1)

        dist_color = (0, 0, 255) if dist < 3.0 else (0, 255, 0)
        cv2.putText(
            frame,
            f"LiDAR Dist: {dist:.2f} m",
            (20, h - 68),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            dist_color,
            1,
        )
        cv2.putText(
            frame,
            f"Radar Objs: {radar_objs} | Range: {radar_rng:.1f}m",
            (20, h - 48),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.4,
            (255, 200, 0),
            1,
        )
        cv2.putText(
            frame,
            f"Radar Velocity: {radar_vel:+.1f} m/s",
            (20, h - 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.4,
            (255, 200, 0),
            1,
        )

        # Bottom Right Overlay: Thermal Camera Mini-Map / PiP
        t_ambient = thermal.get("ambient_temp_c", 25.0)
        t_max = thermal.get("max_temp_c", 28.0)
        t_hotspot = thermal.get("hotspot_detected", False)

        pip_w, pip_h = 130, 80
        pip_x, pip_y = w - pip_w - 10, h - pip_h - 10

        # Thermal PiP background box
        cv2.rectangle(frame, (pip_x, pip_y), (pip_x + pip_w, pip_y + pip_h), (0, 0, 0), -1)
        pip_border = (0, 0, 255) if t_hotspot else (255, 255, 255)
        cv2.rectangle(frame, (pip_x, pip_y), (pip_x + pip_w, pip_y + pip_h), pip_border, 1)

        # Synthetic thermal false-color patch inside PiP
        thermal_patch = np.zeros((35, pip_w - 10, 3), dtype=np.uint8)
        if t_hotspot:
            # Hot spot centered
            thermal_patch[:, :] = [0, 100, 255]  # Orange/Red
            cv2.circle(thermal_patch, (thermal_patch.shape[1] // 2, 17), 10, (0, 0, 255), -1)
        else:
            thermal_patch[:, :] = [180, 50, 50]  # Cool purple/blue

        frame[pip_y + 20 : pip_y + 20 + 35, pip_x + 5 : pip_x + pip_w - 5] = thermal_patch

        cv2.putText(
            frame,
            "THERMAL PiP",
            (pip_x + 8, pip_y + 14),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.35,
            (200, 200, 200),
            1,
        )
        cv2.putText(
            frame,
            f"MAX: {t_max:.1f}C {'[!]' if t_hotspot else ''}",
            (pip_x + 8, pip_y + pip_h - 8),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.35,
            (0, 0, 255) if t_hotspot else (0, 255, 0),
            1,
        )
