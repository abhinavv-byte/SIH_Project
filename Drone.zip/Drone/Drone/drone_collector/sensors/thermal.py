"""Thermal sensor — reads thermal camera matrix / IR temperature data or simulates thermal feed."""

from __future__ import annotations

import random
from datetime import datetime, timezone
from queue import Queue
from typing import Any

from .base import BaseSensor


class ThermalSensor(BaseSensor):
    """Thermal sensor / IR camera (e.g., MLX90640, FLIR Lepton, or I2C/Serial IR sensors).

    Collects ambient temperature, min/max/average scene temperatures,
    and detects hotspots (e.g., humans, motors, fire).
    Falls back to realistic simulation if hardware is unavailable.
    """

    def __init__(
        self,
        queue: Queue,
        port: str | None = None,
        i2c_bus: int | None = None,
        simulate: bool = False,
        interval: float = 0.5,
    ) -> None:
        super().__init__("Thermal", queue, interval)
        self.port = port
        self.i2c_bus = i2c_bus
        self.simulate = simulate

        self._device = None
        self._sim_ambient = 25.0
        self._sim_hotspot_active = False
        self._frame_id = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        if self.simulate:
            return
        # If real hardware drivers like adafruit-circuitpython-mlx90640 or serial thermal exist:
        try:
            if self.port:
                import serial  # noqa: PLC0415
                self._device = serial.Serial(self.port, 115200, timeout=1)
            else:
                # Could initialize I2C / SMBus or standard thermal camera SDK
                raise RuntimeError("No direct I2C bus or serial port configured.")
        except Exception as exc:  # noqa: BLE001
            self.queue.put(
                {
                    "sensor": self.name,
                    "error": f"Thermal hardware initialization failed ({exc}). Falling back to simulation.",
                }
            )
            self.simulate = True

    def _teardown(self) -> None:
        if self._device and hasattr(self._device, "close"):
            self._device.close()

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self) -> dict[str, Any]:
        self._frame_id += 1
        if self.simulate:
            return self._simulated_reading()
        return self._hardware_reading()

    def _hardware_reading(self) -> dict[str, Any]:
        """Read from serial or I2C thermal sensor."""
        # Generic ASCII / JSON parsing or binary frame
        try:
            if self._device and hasattr(self._device, "readline"):
                line = self._device.readline().decode("utf-8", errors="ignore").strip()
                if line and "," in line:
                    # Example format: ambient,min,max,avg
                    parts = [float(p) for p in line.split(",")[:4]]
                    return {
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "frame_id": self._frame_id,
                        "ambient_temp_c": parts[0],
                        "min_temp_c": parts[1],
                        "max_temp_c": parts[2],
                        "avg_temp_c": parts[3],
                        "hotspot_detected": parts[2] > 40.0,
                    }
        except Exception:  # noqa: BLE001
            pass
        return self._simulated_reading()

    def _simulated_reading(self) -> dict[str, Any]:
        """Generate realistic thermal sensor variations with intermittent hotspots."""
        self._sim_ambient += random.uniform(-0.1, 0.1)
        self._sim_ambient = max(15.0, min(45.0, self._sim_ambient))

        # Occasionally trigger a hotspot (e.g. drone flying over an engine, person, or warm spot)
        if random.random() < 0.15:
            self._sim_hotspot_active = not self._sim_hotspot_active

        if self._sim_hotspot_active:
            max_temp = round(self._sim_ambient + random.uniform(20.0, 45.0), 2)
            hotspot = True
        else:
            max_temp = round(self._sim_ambient + random.uniform(2.0, 6.0), 2)
            hotspot = False

        min_temp = round(self._sim_ambient - random.uniform(1.0, 4.0), 2)
        avg_temp = round((min_temp + max_temp) / 2.0 + random.uniform(-1.0, 1.0), 2)

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "frame_id": self._frame_id,
            "ambient_temp_c": round(self._sim_ambient, 2),
            "min_temp_c": min_temp,
            "max_temp_c": max_temp,
            "avg_temp_c": avg_temp,
            "hotspot_detected": hotspot,
        }
