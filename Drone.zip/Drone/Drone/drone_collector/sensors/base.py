"""Abstract base sensor class."""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from queue import Queue
from typing import Any


class BaseSensor(ABC):
    """Abstract base class for all drone sensors.

    Each sensor runs in its own daemon thread, continuously producing
    readings that are pushed onto the shared data queue.
    """

    def __init__(self, name: str, queue: Queue, interval: float = 0.5) -> None:
        """Initialise the sensor.

        Args:
            name: Human-readable sensor name (used in logging/UI).
            queue: Shared queue where readings are pushed.
            interval: Seconds between readings.
        """
        self.name = name
        self.queue = queue
        self.interval = interval

        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._latest: dict[str, Any] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the sensor reading thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, name=f"{self.name}-thread", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the sensor thread to stop and wait for it to finish."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=3)

    @property
    def latest(self) -> dict[str, Any]:
        """Return the most recent reading (thread-safe)."""
        with self._lock:
            return dict(self._latest)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run(self) -> None:
        """Main loop — calls :meth:`read` repeatedly."""
        self._setup()
        while not self._stop_event.wait(self.interval):
            try:
                reading = self.read()
                if reading:
                    with self._lock:
                        self._latest = reading
                    self.queue.put({"sensor": self.name, "data": reading})
            except Exception as exc:  # noqa: BLE001
                self.queue.put({"sensor": self.name, "error": str(exc)})
        self._teardown()

    # ------------------------------------------------------------------
    # Subclass hooks
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        """Called once before the read loop starts. Override as needed."""

    def _teardown(self) -> None:
        """Called once after the read loop ends. Override as needed."""

    @abstractmethod
    def read(self) -> dict[str, Any]:
        """Read one measurement and return it as a plain dict.

        The dict must always include a ``"timestamp"`` key (ISO-8601 string).
        """
