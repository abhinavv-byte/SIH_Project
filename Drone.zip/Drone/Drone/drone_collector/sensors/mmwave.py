"""mm-Wave radar sensor — reads UART data or simulates point-cloud output."""

from __future__ import annotations

import random
import struct
from datetime import datetime, timezone
from queue import Queue
from typing import Any

from .base import BaseSensor


# ---------------------------------------------------------------------------
# TI IWR series magic bytes / frame header
# ---------------------------------------------------------------------------
_MAGIC = b"\x02\x01\x04\x03\x06\x05\x08\x07"
_HEADER_SIZE = 40  # bytes


class MmWaveSensor(BaseSensor):
    """mm-Wave radar sensor (generic TI IWR-compatible protocol).

    Reads binary UART frames and extracts detected-object TLVs.
    Falls back to simulation if the port is unavailable.
    """

    def __init__(
        self,
        queue: Queue,
        port: str = "COM4",
        baud: int = 115200,
        simulate: bool = False,
        interval: float = 0.1,
    ) -> None:
        super().__init__("mm-Wave", queue, interval)
        self.port = port
        self.baud = baud
        self.simulate = simulate

        self._serial = None
        self._sim_t = 0.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        if self.simulate:
            return
        try:
            import serial  # noqa: PLC0415

            self._serial = serial.Serial(self.port, self.baud, timeout=1)
        except Exception as exc:  # noqa: BLE001
            self.queue.put(
                {
                    "sensor": self.name,
                    "error": f"Cannot open {self.port}: {exc}. Falling back to simulation.",
                }
            )
            self.simulate = True

    def _teardown(self) -> None:
        if self._serial and self._serial.is_open:
            self._serial.close()

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self) -> dict[str, Any]:
        if self.simulate:
            return self._simulated_reading()
        return self._serial_reading()

    # ------------------------------------------------------------------
    # Serial reading (TI IWR binary protocol)
    # ------------------------------------------------------------------

    def _serial_reading(self) -> dict[str, Any]:
        """Read one frame from the radar UART stream."""
        # Sync to magic word
        buf = b""
        while _MAGIC not in buf:
            byte = self._serial.read(1)
            if not byte:
                return self._simulated_reading()
            buf += byte
            if len(buf) > 256:
                buf = buf[-8:]

        # Read frame header
        header_raw = self._serial.read(_HEADER_SIZE)
        if len(header_raw) < _HEADER_SIZE:
            return self._simulated_reading()

        try:
            # Unpack relevant header fields (little-endian)
            # Offsets based on TI DCA1000 / mmWave SDK data format
            total_packet_len = struct.unpack_from("<I", header_raw, 12)[0]
            num_tlvs = struct.unpack_from("<I", header_raw, 32)[0]

            payload_size = total_packet_len - _HEADER_SIZE - len(_MAGIC)
            payload = self._serial.read(max(0, payload_size))

            objects = self._parse_tlvs(payload, num_tlvs)
        except (struct.error, Exception):  # noqa: BLE001
            return self._simulated_reading()

        return self._summarise_objects(objects)

    def _parse_tlvs(
        self, payload: bytes, num_tlvs: int
    ) -> list[dict[str, float]]:
        """Parse TLV blocks from the radar frame payload."""
        objects: list[dict[str, float]] = []
        offset = 0
        for _ in range(num_tlvs):
            if offset + 8 > len(payload):
                break
            tlv_type = struct.unpack_from("<I", payload, offset)[0]
            tlv_len = struct.unpack_from("<I", payload, offset + 4)[0]
            offset += 8

            if tlv_type == 1:  # Detected objects
                obj_size = 16  # x, y, z, vel (4 × float32)
                num_obj = tlv_len // obj_size
                for i in range(num_obj):
                    if offset + obj_size > len(payload):
                        break
                    x, y, z, vel = struct.unpack_from(
                        "<ffff", payload, offset + i * obj_size
                    )
                    distance = (x**2 + y**2 + z**2) ** 0.5
                    objects.append(
                        {"range_m": round(distance, 2), "velocity_ms": round(vel, 2)}
                    )
                offset += tlv_len
            else:
                offset += tlv_len

        return objects

    def _summarise_objects(self, objects: list[dict]) -> dict[str, Any]:
        num_objects = len(objects)
        nearest_range = min((o["range_m"] for o in objects), default=0.0)
        avg_velocity = (
            sum(o["velocity_ms"] for o in objects) / num_objects
            if num_objects
            else 0.0
        )
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "num_objects": num_objects,
            "nearest_range_m": round(nearest_range, 2),
            "velocity_ms": round(avg_velocity, 2),
            "signal_strength": random.randint(60, 100),  # SNR proxy
        }

    # ------------------------------------------------------------------
    # Simulation
    # ------------------------------------------------------------------

    def _simulated_reading(self) -> dict[str, Any]:
        """Simulate a radar scene with a few moving objects."""
        self._sim_t += self.interval
        # 1-4 objects detected, appearing and disappearing
        num_objects = max(0, int(2 + 2 * abs(random.gauss(0, 0.5))))
        nearest = round(max(0.5, 8.0 + 6.0 * random.gauss(0, 0.3)), 2)
        velocity = round(random.gauss(0, 1.5), 2)
        snr = random.randint(55, 95)
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "num_objects": num_objects,
            "nearest_range_m": nearest,
            "velocity_ms": velocity,
            "signal_strength": snr,
        }
