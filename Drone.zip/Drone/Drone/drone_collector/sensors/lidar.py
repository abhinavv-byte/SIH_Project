"""Camera / LiDAR sensor — captures frames via OpenCV or simulates data."""

from __future__ import annotations

import random
from datetime import datetime, timezone
from queue import Queue
from typing import Any

from .base import BaseSensor


class LidarSensor(BaseSensor):
    """Camera/LiDAR sensor that estimates distance from frame analysis.

    In simulation mode a realistic noisy distance reading is generated.
    In hardware mode it uses OpenCV to capture frames and applies a
    simple depth heuristic (works well with structured light / ToF cameras).
    """

    def __init__(
        self,
        queue: Queue,
        camera_id: int = 0,
        simulate: bool = False,
        interval: float = 0.05,
        use_camera: bool = True,
    ) -> None:
        super().__init__("LiDAR", queue, interval)
        self.camera_id = camera_id
        self.simulate = simulate
        self.use_camera = use_camera

        self._cap = None
        self._frame_id = 0
        self._sim_distance = 5.0
        self._sim_trend = -0.05
        self._last_frame = None

    @property
    def latest_frame(self) -> Any:
        return self._last_frame

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        if not self.use_camera:
            self.simulate = True
            return
        try:
            import cv2  # noqa: PLC0415

            # Open default laptop webcam
            self._cap = cv2.VideoCapture(self.camera_id, cv2.CAP_ANY)
            if not self._cap.isOpened():
                raise RuntimeError(f"Cannot open webcam index {self.camera_id}")
            self.simulate = False
        except Exception as exc:  # noqa: BLE001
            self.queue.put(
                {
                    "sensor": self.name,
                    "error": f"Webcam {self.camera_id} unavailable ({exc}). Using synthetic camera.",
                }
            )
            self.simulate = True

    def _teardown(self) -> None:
        if self._cap is not None:
            self._cap.release()

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self) -> dict[str, Any]:
        self._frame_id += 1
        if self.simulate:
            return self._simulated_reading()
        return self._camera_reading()

    def _camera_reading(self) -> dict[str, Any]:
        import cv2  # noqa: PLC0415
        import numpy as np  # noqa: PLC0415

        ret, frame = self._cap.read()
        if not ret:
            self._last_frame = None
            return self._simulated_reading()

        self._last_frame = frame

        # Basic heuristic: analyse brightness of lower-centre region
        # (bright = close obstacle, dark = open space / far).
        h, w = frame.shape[:2]
        roi = frame[h // 2 :, w // 4 : 3 * w // 4]
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        mean_brightness = float(np.mean(gray))
        # Map brightness 0-255 → distance 0.5-20 m (inverse relationship)
        estimated_distance = round(20.0 - (mean_brightness / 255.0) * 19.5, 2)
        object_detected = estimated_distance < 3.0

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "frame_id": self._frame_id,
            "estimated_distance_m": max(0.5, estimated_distance),
            "object_detected": object_detected,
        }

    def _simulated_reading(self) -> dict[str, Any]:
        """Simulate a slowly varying distance with occasional obstacles."""
        self._sim_distance += self._sim_trend + random.gauss(0, 0.1)
        self._sim_distance = max(0.5, min(20.0, self._sim_distance))
        if self._sim_distance <= 0.5 or self._sim_distance >= 20.0:
            self._sim_trend *= -1  # bounce

        object_detected = self._sim_distance < 3.0
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "frame_id": self._frame_id,
            "estimated_distance_m": round(self._sim_distance, 2),
            "object_detected": object_detected,
        }
