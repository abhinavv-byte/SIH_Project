"""GPS sensor — reads NMEA sentences over serial or simulates data."""

from __future__ import annotations

import math
import random
import time
from datetime import datetime, timezone
from queue import Queue
from typing import Any

from .base import BaseSensor


# ---------------------------------------------------------------------------
# NMEA helpers
# ---------------------------------------------------------------------------

def _parse_gga(sentence: str) -> dict[str, Any] | None:
    """Parse a GGA NMEA sentence into a dict."""
    parts = sentence.strip().split(",")
    if len(parts) < 10:
        return None
    try:
        raw_lat = parts[2]
        lat_dir = parts[3]
        raw_lon = parts[4]
        lon_dir = parts[5]
        satellites = int(parts[7]) if parts[7] else 0
        altitude = float(parts[9]) if parts[9] else 0.0

        def _nmea_to_decimal(raw: str, direction: str) -> float:
            if not raw:
                return 0.0
            if len(raw) > 5:
                deg = float(raw[:2 if direction in ("N", "S") else 3])
                minutes = float(raw[2 if direction in ("N", "S") else 3:])
            else:
                return 0.0
            decimal = deg + minutes / 60.0
            if direction in ("S", "W"):
                decimal *= -1
            return decimal

        return {
            "latitude": _nmea_to_decimal(raw_lat, lat_dir),
            "longitude": _nmea_to_decimal(raw_lon, lon_dir),
            "altitude_m": altitude,
            "satellites": satellites,
        }
    except (ValueError, IndexError):
        return None


def _parse_rmc(sentence: str) -> dict[str, Any] | None:
    """Parse a RMC NMEA sentence for speed."""
    parts = sentence.strip().split(",")
    if len(parts) < 8:
        return None
    try:
        speed_knots = float(parts[7]) if parts[7] else 0.0
        return {"speed_kmh": round(speed_knots * 1.852, 2)}
    except (ValueError, IndexError):
        return None


# ---------------------------------------------------------------------------
# GPS Sensor
# ---------------------------------------------------------------------------

class GPSSensor(BaseSensor):
    """GPS sensor that reads NMEA over serial or generates simulated data."""

    def __init__(
        self,
        queue: Queue,
        port: str = "COM3",
        baud: int = 9600,
        simulate: bool = False,
        interval: float = 1.0,
    ) -> None:
        super().__init__("GPS", queue, interval)
        self.port = port
        self.baud = baud
        self.simulate = simulate

        self._serial = None
        # Simulation state — start near a fixed origin and drift slowly
        self._sim_lat = 12.9716
        self._sim_lon = 77.5946
        self._sim_alt = 120.0
        self._sim_speed = 0.0
        self._sim_t = 0.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        if self.simulate:
            return
        try:
            import serial  # noqa: PLC0415

            self._serial = serial.Serial(self.port, self.baud, timeout=2)
        except Exception as exc:  # noqa: BLE001
            self.queue.put(
                {
                    "sensor": self.name,
                    "error": f"Cannot open {self.port}: {exc}. Falling back to simulation.",
                }
            )
            self.simulate = True

    def _teardown(self) -> None:
        if self._serial and self._serial.is_open:
            self._serial.close()

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self) -> dict[str, Any]:
        if self.simulate:
            return self._simulated_reading()
        return self._serial_reading()

    def _serial_reading(self) -> dict[str, Any]:
        reading: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "latitude": 0.0,
            "longitude": 0.0,
            "altitude_m": 0.0,
            "speed_kmh": 0.0,
            "satellites": 0,
        }
        lines_read = 0
        while lines_read < 20:
            line = self._serial.readline().decode("ascii", errors="ignore")
            if line.startswith("$GPGGA") or line.startswith("$GNGGA"):
                parsed = _parse_gga(line)
                if parsed:
                    reading.update(parsed)
            elif line.startswith("$GPRMC") or line.startswith("$GNRMC"):
                parsed = _parse_rmc(line)
                if parsed:
                    reading.update(parsed)
            lines_read += 1
        reading["timestamp"] = datetime.now(timezone.utc).isoformat()
        return reading

    def _simulated_reading(self) -> dict[str, Any]:
        """Generate smoothly varying simulated GPS data."""
        self._sim_t += self.interval
        # Gentle circular drift
        self._sim_lat += math.sin(self._sim_t * 0.1) * 0.00005
        self._sim_lon += math.cos(self._sim_t * 0.1) * 0.00005
        self._sim_alt += random.uniform(-0.5, 0.5)
        self._sim_speed = max(0.0, self._sim_speed + random.uniform(-1, 1))
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "latitude": round(self._sim_lat, 6),
            "longitude": round(self._sim_lon, 6),
            "altitude_m": round(self._sim_alt, 2),
            "speed_kmh": round(self._sim_speed, 2),
            "satellites": random.randint(6, 12),
        }
