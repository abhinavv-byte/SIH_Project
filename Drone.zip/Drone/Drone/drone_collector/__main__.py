"""CLI entry point for the Drone Sensor Data Collector."""

from __future__ import annotations

import os
import queue
import sys
import threading
import time
from pathlib import Path

import click
from rich.console import Console

from .dashboard import Dashboard
from .database import Database
from .exporter import export_session
from .sensors.gps import GPSSensor
from .sensors.lidar import LidarSensor
from .sensors.mmwave import MmWaveSensor
from .sensors.thermal import ThermalSensor
from .visualizer import LiveFeedVisualizer

console = Console()


# ---------------------------------------------------------------------------
# Writer thread — drains the shared queue into SQLite
# ---------------------------------------------------------------------------

def _writer_loop(
    data_queue: queue.Queue,
    db: Database,
    stop_event: threading.Event,
    paused_flag: list[bool],
) -> None:
    """Background thread that pulls readings from the queue and inserts them."""
    while not stop_event.is_set() or not data_queue.empty():
        try:
            item = data_queue.get(timeout=0.2)
        except queue.Empty:
            continue

        if "error" in item:
            # Errors from sensors: log but don't crash
            console.log(f"[yellow]Sensor warning ({item['sensor']}): {item['error']}[/]")
            continue

        if not paused_flag[0]:
            db.insert(item["sensor"], item["data"])


# ---------------------------------------------------------------------------
# Keyboard input thread
# ---------------------------------------------------------------------------

def _keyboard_loop(
    command_queue: queue.Queue,
    stop_event: threading.Event,
) -> None:
    """Read single-character keyboard input in a background thread."""
    while not stop_event.is_set():
        try:
            if sys.platform == "win32":
                import msvcrt  # noqa: PLC0415
                if msvcrt.kbhit():
                    ch = msvcrt.getwch()
                    command_queue.put(ch.lower())
                else:
                    time.sleep(0.05)
            else:
                import select  # noqa: PLC0415
                import tty  # noqa: PLC0415
                import termios  # noqa: PLC0415
                fd = sys.stdin.fileno()
                old = termios.tcgetattr(fd)
                try:
                    tty.setraw(fd)
                    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
                    if rlist:
                        ch = sys.stdin.read(1)
                        command_queue.put(ch.lower())
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except Exception:  # noqa: BLE001
            time.sleep(0.1)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

@click.command()
@click.option("--simulate", is_flag=True, default=False,
              help="Run with simulated sensor data (no hardware needed).")
@click.option("--gps-port", default=None,
              help="Serial port for GPS (e.g. COM3, /dev/ttyUSB0).")
@click.option("--mmwave-port", default=None,
              help="Serial port for mm-Wave radar (e.g. COM4, /dev/ttyUSB1).")
@click.option("--thermal-port", default=None,
              help="Serial port for Thermal camera (e.g. COM5, /dev/ttyUSB2).")
@click.option("--camera-id", default=0, show_default=True,
              help="OpenCV camera index.")
@click.option("--baud-gps", default=9600, show_default=True,
              help="GPS baud rate.")
@click.option("--baud-mmwave", default=115200, show_default=True,
              help="mm-Wave baud rate.")
@click.option("--db", "db_path", default="drone_data.db", show_default=True,
              help="SQLite database file path.")
@click.option("--notes", default="", help="Session notes stored in the database.")
@click.option("--show-feed/--no-feed", default=True, show_default=True,
              help="Show live OpenCV camera HUD and simulation feed window.")
@click.option("--webcam/--no-webcam", default=True, show_default=True,
              help="Use physical laptop camera/webcam even in simulation mode.")
def cli(
    simulate: bool,
    gps_port: str | None,
    mmwave_port: str | None,
    thermal_port: str | None,
    camera_id: int,
    baud_gps: int,
    baud_mmwave: int,
    db_path: str,
    notes: str,
    show_feed: bool,
    webcam: bool,
) -> None:
    """Drone Sensor Data Collector

    Collects data from GPS, Camera/LiDAR, mm-Wave radar, and Thermal sensors simultaneously,
    stores readings in SQLite, and displays a real-time terminal dashboard + live video HUD.

    \b
    Dashboard controls:
      q  Quit and save session
      e  Export current session to CSV
      p  Pause / resume recording
    """
    # Resolve defaults from env or platform
    if gps_port is None:
        gps_port = os.environ.get(
            "GPS_PORT", "COM3" if sys.platform == "win32" else "/dev/ttyUSB0"
        )
    if mmwave_port is None:
        mmwave_port = os.environ.get(
            "MMWAVE_PORT", "COM4" if sys.platform == "win32" else "/dev/ttyUSB1"
        )
    if thermal_port is None:
        thermal_port = os.environ.get(
            "THERMAL_PORT", "COM5" if sys.platform == "win32" else "/dev/ttyUSB2"
        )

    # --- Database ---
    db = Database(db_path)
    db.connect()
    session_id = db.start_session(notes=notes)

    # --- Shared state ---
    data_queue: queue.Queue = queue.Queue(maxsize=1000)
    cmd_queue: queue.Queue = queue.Queue()
    stop_event = threading.Event()
    paused_flag = [False]  # mutable container so threads can share it

    # --- Sensors ---
    lidar_sensor = LidarSensor(
        queue=data_queue,
        camera_id=camera_id,
        simulate=simulate,
        interval=0.05,
        use_camera=webcam,
    )
    sensors = [
        GPSSensor(
            queue=data_queue,
            port=gps_port,
            baud=baud_gps,
            simulate=simulate,
            interval=1.0,
        ),
        lidar_sensor,
        MmWaveSensor(
            queue=data_queue,
            port=mmwave_port,
            baud=baud_mmwave,
            simulate=simulate,
            interval=0.05,
        ),
        ThermalSensor(
            queue=data_queue,
            port=thermal_port,
            simulate=simulate,
            interval=0.5,
        ),
    ]

    # --- Start sensor threads ---
    for sensor in sensors:
        sensor.start()

    # --- Start visualizer if enabled ---
    visualizer: LiveFeedVisualizer | None = None
    if show_feed:
        visualizer = LiveFeedVisualizer(title="Drone HUD & Live Sensor Feed", queue=data_queue)
        visualizer.start()

    # --- Start writer thread ---
    writer = threading.Thread(
        target=_writer_loop,
        args=(data_queue, db, stop_event, paused_flag),
        daemon=True,
        name="writer",
    )
    writer.start()

    # --- Start keyboard thread ---
    kb_thread = threading.Thread(
        target=_keyboard_loop,
        args=(cmd_queue, stop_event),
        daemon=True,
        name="keyboard",
    )
    kb_thread.start()

    # --- Dashboard ---
    with Dashboard(db, session_id) as dash:
        try:
            while True:
                # Collect latest readings from each sensor
                latest = {s.name: s.latest for s in sensors}
                if visualizer is not None:
                    latest["HumanDetection"] = visualizer.latest
                dash.update(latest)

                # Update live video feed / HUD window
                if visualizer is not None:
                    raw_frame = getattr(lidar_sensor, "latest_frame", None)
                    visualizer.update_telemetry(latest, raw_frame=raw_frame)

                # Handle keyboard commands
                while not cmd_queue.empty():
                    cmd = cmd_queue.get_nowait()
                    if cmd == "q":
                        raise KeyboardInterrupt
                    elif cmd == "e":
                        try:
                            path = export_session(db)
                            console.log(f"[green]✓ Exported to {path}[/]")
                        except Exception as exc:  # noqa: BLE001
                            console.log(f"[red]Export failed: {exc}[/]")
                    elif cmd == "p":
                        paused_flag[0] = not paused_flag[0]

                time.sleep(0.1)

        except KeyboardInterrupt:
            pass
        finally:
            # Graceful shutdown
            stop_event.set()
            if visualizer is not None:
                visualizer.stop()
            for sensor in sensors:
                sensor.stop()
            writer.join(timeout=3)
            db.close()
            console.print("\n[bold green]Session saved. Goodbye![/]")


if __name__ == "__main__":
    # Keep ``python -m drone_collector`` aligned with the installed
    # ``drone-collector`` command, whose entry point is main.cli.
    from .main import cli as main_cli

    main_cli()
