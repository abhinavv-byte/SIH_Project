"""Offline, data-grounded assistant for drone recording sessions.

The assistant talks only to a local Ollama server and supplies it with a
snapshot of the active SQLite session.  Sensor data never leaves the computer.
"""

from __future__ import annotations

import json
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from .database import Database


class OfflineDataAssistant:
    """Answer natural-language questions using local session data and Ollama."""

    def __init__(self, db: Database, model: str = "phi4-mini") -> None:
        self.db = db
        self.model = model

    def ask(self, question: str) -> str:
        """Return a data-grounded answer from the locally running model."""
        direct_answer = self._human_count_answer(question)
        if direct_answer is not None:
            return direct_answer

        direct_answer = self._sensor_reading_answer(question)
        if direct_answer is not None:
            return direct_answer

        # Keep open-ended AI prompts small; common telemetry questions are
        # answered exactly above without invoking the language model.
        context = self.db.ai_session_snapshot(recent_limit=3)
        if not context:
            return "No active recording session is available yet."

        prompt = (
            "You are the offline Drone 5 flight-data assistant. Answer naturally, "
            "but use only the supplied SQLite session data. Do not invent values, "
            "events, causes, or sensor readings. If the snapshot cannot answer the "
            "question, say that clearly and mention what data is available. Return "
            "only a concise plain-language answer: never provide code, pseudocode, "
            "JSON, or an explanation of how to process the data.\n\n"
            f"Question: {question}\n\n"
            "Recorded session snapshot:\n"
            f"{json.dumps(context, ensure_ascii=False, default=str)}"
        )
        payload = json.dumps(
            {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {"num_predict": 80, "temperature": 0.1},
            },
        ).encode("utf-8")
        request = Request(
            "http://127.0.0.1:11434/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urlopen(request, timeout=300) as response:  # noqa: S310 - localhost only
                result: dict[str, Any] = json.loads(response.read().decode("utf-8"))
        except URLError:
            return (
                "The offline AI is not available. Start Ollama locally and make sure "
                f"the {self.model!r} model has been downloaded."
            )
        except TimeoutError:
            return "The offline AI took too long to respond. Please try again."
        except (OSError, json.JSONDecodeError, KeyError) as exc:
            return f"The offline AI could not answer: {exc}"

        return result.get("response", "The offline AI returned no answer.").strip()

    def _human_count_answer(self, question: str) -> str | None:
        """Give exact, plain-language answers for human-detection questions."""
        words = question.lower()
        if not any(term in words for term in ("human", "people", "person")):
            return None

        summary = self.db.human_detection_summary()
        if not summary:
            return "No human-detection data has been recorded in this session yet."

        latest = summary["latest"]
        totals = summary["totals"]
        current = latest["human_count"]
        peak = totals["peak_count"] or 0
        samples = totals["detected_samples"] or 0
        confidence = latest["avg_confidence"]

        return (
            f"The latest RGB-camera reading shows {current} visible "
            f"human{'s' if current != 1 else ''} ({confidence:.0%} confidence). "
            f"So far in this session, the peak simultaneous count is {peak}, and "
            f"humans were present in {samples} detection samples."
        )

    def _sensor_reading_answer(self, question: str) -> str | None:
        """Answer common live telemetry questions exactly and without latency."""
        words = question.lower()

        if any(term in words for term in ("temperature", "thermal", "hotspot", "heat")):
            reading = self.db.latest_sensor_reading("thermal")
            if not reading:
                return "No thermal reading has been recorded in this session yet."
            hotspot = "A hotspot is detected." if reading["hotspot_detected"] else "No hotspot is detected."
            return (
                f"The latest thermal reading is {reading['ambient_temp_c']:.1f} °C ambient, "
                f"with {reading['min_temp_c']:.1f} °C minimum, {reading['max_temp_c']:.1f} °C "
                f"maximum, and {reading['avg_temp_c']:.1f} °C average. {hotspot}"
            )

        if any(term in words for term in ("gps", "location", "latitude", "longitude", "altitude", "speed")):
            reading = self.db.latest_sensor_reading("gps")
            if not reading:
                return "No GPS reading has been recorded in this session yet."
            return (
                f"The latest GPS position is {reading['latitude']:.6f}, {reading['longitude']:.6f}; "
                f"altitude is {reading['altitude_m']:.1f} m, speed is {reading['speed_kmh']:.1f} km/h, "
                f"with {reading['satellites']} satellites."
            )

        if any(term in words for term in ("lidar", "camera", "obstacle", "distance")):
            reading = self.db.latest_sensor_reading("lidar")
            if not reading:
                return "No LiDAR reading has been recorded in this session yet."
            status = "An obstacle is detected." if reading["object_detected"] else "No obstacle is detected."
            return f"The latest LiDAR distance is {reading['estimated_distance_m']:.2f} m. {status}"

        if any(term in words for term in ("radar", "mmwave", "mm-wave", "velocity", "signal")):
            reading = self.db.latest_sensor_reading("mmwave")
            if not reading:
                return "No mm-Wave radar reading has been recorded in this session yet."
            return (
                f"The latest radar reading shows {reading['num_objects']} object(s), "
                f"nearest range {reading['nearest_range_m']:.2f} m, velocity "
                f"{reading['velocity_ms']:+.2f} m/s, and signal strength "
                f"{reading['signal_strength']} dB."
            )

        return None
