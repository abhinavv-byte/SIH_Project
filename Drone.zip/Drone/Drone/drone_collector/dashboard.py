"""Real-time terminal dashboard using Rich."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from rich.columns import Columns
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from .database import Database


console = Console()

# ANSI colour shortcuts (Rich markup)
_GREEN = "bold green"
_YELLOW = "bold yellow"
_RED = "bold red"
_CYAN = "bold cyan"
_DIM = "dim"


# ---------------------------------------------------------------------------
# Panel builders
# ---------------------------------------------------------------------------

def _header_panel(session_id: int, start_time: float, paused: bool, counts: dict) -> Panel:
    elapsed = int(time.time() - start_time)
    h, remainder = divmod(elapsed, 3600)
    m, s = divmod(remainder, 60)
    status = "[bold yellow]PAUSED[/]" if paused else "[bold green]RECORDING[/]"
    total = sum(counts.values())
    text = (
        f"  Session [bold cyan]#{session_id}[/]   "
        f"Duration [bold]{h:02d}:{m:02d}:{s:02d}[/]   "
        f"Status {status}   "
        f"Total readings [bold]{total:,}[/]  "
        f"  GPS: {counts.get('gps', 0):,}  "
        f"LiDAR: {counts.get('lidar', 0):,}  "
        f"mm-Wave: {counts.get('mmwave', 0):,}  "
        f"Thermal: {counts.get('thermal', 0):,}  "
        f"Human: {counts.get('human_detection', 0):,}"
    )
    return Panel(Text.from_markup(text), title="[*] Drone Sensor Data Collector", style="bold white on dark_blue")


def _gps_panel(data: dict[str, Any]) -> Panel:
    if not data:
        return Panel("[dim]No GPS data yet...[/]", title="[GPS]  GPS", border_style="blue")

    lat = data.get("latitude", 0)
    lon = data.get("longitude", 0)
    alt = data.get("altitude_m", 0)
    spd = data.get("speed_kmh", 0)
    sats = data.get("satellites", 0)
    ts = data.get("timestamp", "")[:19].replace("T", " ")

    sat_color = _GREEN if sats >= 6 else _YELLOW if sats >= 4 else _RED

    table = Table.grid(padding=(0, 2))
    table.add_row("Latitude",  f"[bold]{lat:+.6f}°[/]")
    table.add_row("Longitude", f"[bold]{lon:+.6f}°[/]")
    table.add_row("Altitude",  f"[bold]{alt:.1f} m[/]")
    table.add_row("Speed",     f"[bold]{spd:.1f} km/h[/]")
    table.add_row("Satellites",f"[{sat_color}]{sats}[/]")
    table.add_row("Updated",   f"[dim]{ts}[/]")

    return Panel(table, title="[GPS]  GPS", border_style="blue")


def _lidar_panel(data: dict[str, Any]) -> Panel:
    if not data:
        return Panel("[dim]No LiDAR data yet...[/]", title="[CAM]  Camera / LiDAR", border_style="cyan")

    dist = data.get("estimated_distance_m", 0)
    obj = data.get("object_detected", False)
    fid = data.get("frame_id", 0)
    ts = data.get("timestamp", "")[:19].replace("T", " ")

    dist_color = _RED if dist < 1.5 else _YELLOW if dist < 3.0 else _GREEN
    obj_text = "[bold red]! YES[/]" if obj else "[green]OK  Clear[/]"

    table = Table.grid(padding=(0, 2))
    table.add_row("Distance",        f"[{dist_color}]{dist:.2f} m[/]")
    table.add_row("Object Detected", obj_text)
    table.add_row("Frame ID",        f"[dim]{fid:,}[/]")
    table.add_row("Updated",         f"[dim]{ts}[/]")

    return Panel(table, title="[CAM]  Camera / LiDAR", border_style="cyan")


def _mmwave_panel(data: dict[str, Any]) -> Panel:
    if not data:
        return Panel("[dim]No mm-Wave data yet...[/]", title="[RDR]  mm-Wave Radar", border_style="magenta")

    num = data.get("num_objects", 0)
    rng = data.get("nearest_range_m", 0)
    vel = data.get("velocity_ms", 0)
    snr = data.get("signal_strength", 0)
    ts  = data.get("timestamp", "")[:19].replace("T", " ")

    rng_color = _RED if rng < 2.0 else _YELLOW if rng < 5.0 else _GREEN
    snr_color = _GREEN if snr >= 70 else _YELLOW if snr >= 50 else _RED

    table = Table.grid(padding=(0, 2))
    table.add_row("Objects Detected", f"[bold]{num}[/]")
    table.add_row("Nearest Range",    f"[{rng_color}]{rng:.2f} m[/]")
    table.add_row("Avg Velocity",     f"[bold]{vel:+.2f} m/s[/]")
    table.add_row("Signal Strength",  f"[{snr_color}]{snr} dB[/]")
    table.add_row("Updated",          f"[dim]{ts}[/]")

    return Panel(table, title="[RDR]  mm-Wave Radar", border_style="magenta")


def _thermal_panel(data: dict[str, Any]) -> Panel:
    if not data:
        return Panel("[dim]No Thermal data yet...[/]", title="[THM]  Thermal Camera", border_style="red")

    ambient = data.get("ambient_temp_c", 0.0)
    min_temp = data.get("min_temp_c", 0.0)
    max_temp = data.get("max_temp_c", 0.0)
    avg_temp = data.get("avg_temp_c", 0.0)
    hotspot = data.get("hotspot_detected", False)
    ts = data.get("timestamp", "")[:19].replace("T", " ")

    max_color = _RED if max_temp >= 45.0 else _YELLOW if max_temp >= 35.0 else _GREEN
    hotspot_text = "[bold red]! HOTSPOT[/]" if hotspot else "[green]OK  Nominal[/]"

    table = Table.grid(padding=(0, 2))
    table.add_row("Ambient Temp",    f"{ambient:.1f} °C")
    table.add_row("Min / Max Temp",  f"{min_temp:.1f} / [{max_color}]{max_temp:.1f}[/] °C")
    table.add_row("Avg Temp",        f"{avg_temp:.1f} °C")
    table.add_row("Thermal Alert",   hotspot_text)
    table.add_row("Updated",         f"[dim]{ts}[/]")

    return Panel(table, title="[THM]  Thermal Camera", border_style="red")


def _human_detection_panel(data: dict[str, Any]) -> Panel:
    if not data:
        return Panel("[dim]No detection data yet...[/]", title="[HUM]  Human Detection", border_style="yellow")

    count = data.get("human_count", 0)
    confidence = data.get("avg_confidence", 0.0)
    source = data.get("source", "")
    ts = data.get("timestamp", "")[:19].replace("T", " ")

    count_color = _RED if count > 0 else _GREEN
    status_text = f"[{count_color}]! {count} DETECTED[/]" if count > 0 else "[green]OK  Clear[/]"

    table = Table.grid(padding=(0, 2))
    table.add_row("Status",     status_text)
    table.add_row("Count",      f"[bold]{count}[/]")
    table.add_row("Avg Conf.",  f"[bold]{confidence * 100:.0f}%[/]" if count else "[dim]-[/]")
    table.add_row("Backend",    f"[dim]{source}[/]")
    table.add_row("Updated",    f"[dim]{ts}[/]")

    return Panel(table, title="[HUM]  Human Detection", border_style="yellow")


def _controls_panel() -> Panel:
    text = (
        "  [bold]q[/] Quit    "
        "[bold]e[/] Export CSV    "
        "[bold]p[/] Pause / Resume    "
        "[bold]a[/] Ask offline AI"
    )
    return Panel(Text.from_markup(text), style="dim", height=3)


# ---------------------------------------------------------------------------
# Main dashboard
# ---------------------------------------------------------------------------

class Dashboard:
    """Manages the Rich Live display."""

    def __init__(self, db: "Database", session_id: int) -> None:
        self.db = db
        self.session_id = session_id
        self.start_time = time.time()
        self.paused = False
        self._live: Live | None = None

    def _build_layout(self) -> Layout:
        counts = self.db.count_readings()
        gps_data = {}
        lidar_data = {}
        mmwave_data = {}
        thermal_data = {}
        human_data = {}

        # Pull latest readings from sensors (stored by main loop)
        if hasattr(self, "_latest"):
            gps_data = self._latest.get("GPS", {})
            lidar_data = self._latest.get("LiDAR", {})
            mmwave_data = self._latest.get("mm-Wave", {})
            thermal_data = self._latest.get("Thermal", {})
            human_data = self._latest.get("HumanDetection", {})

        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="sensors"),
            Layout(name="controls", size=3),
        )
        layout["header"].update(_header_panel(self.session_id, self.start_time, self.paused, counts))
        layout["sensors"].split_row(
            Layout(_gps_panel(gps_data), name="gps"),
            Layout(_lidar_panel(lidar_data), name="lidar"),
            Layout(_mmwave_panel(mmwave_data), name="mmwave"),
            Layout(_thermal_panel(thermal_data), name="thermal"),
            Layout(_human_detection_panel(human_data), name="human"),
        )
        layout["controls"].update(_controls_panel())
        return layout

    def update(self, latest: dict[str, dict]) -> None:
        """Push fresh sensor readings into the display."""
        self._latest = latest
        if self._live:
            self._live.update(self._build_layout())

    def __enter__(self) -> "Dashboard":
        self._live = Live(
            self._build_layout(),
            console=console,
            refresh_per_second=2,
            screen=True,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *args) -> None:
        if self._live:
            self._live.__exit__(*args)

    def pause_display(self) -> None:
        """Temporarily release the terminal for an interactive AI question."""
        if self._live:
            self._live.stop()

    def resume_display(self) -> None:
        """Restore the live dashboard after an interactive prompt."""
        if self._live:
            self._live.start()
