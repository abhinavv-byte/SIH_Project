# Sensor Data Collector

A Python program that simultaneously collects data from multiple drone sensors, stores readings in SQLite, displays a real-time terminal dashboard, and exports data to CSV.

## Sensors Supported

| Sensor | Interface | Data Collected |
|--------|-----------|----------------|
| GPS | Serial (NMEA) | Lat, Lon, Alt, Speed, Satellites |
| Camera / LiDAR | USB / OpenCV | Distance estimate, object detection |
| mm-Wave Radar | Serial (UART) | Objects, range, velocity, signal strength |
| Thermal Camera | Serial / I2C | Ambient temp, Min/Max/Avg temp, Hotspot alert |

## Installation

```bash
pip install -e .
```

## Usage

### Simulate (no hardware required)
```bash
drone-collector --simulate
```

### With real hardware
```bash
drone-collector --gps-port COM3 --mmwave-port COM4 --thermal-port COM5 --camera-id 0
```

### Options
```
--simulate          Run with simulated sensor data (no hardware needed)
--show-feed         Display OpenCV live HUD & drone camera window (default: ON)
--no-feed           Run in headless mode (terminal dashboard only)
--webcam            Use physical laptop camera/webcam in simulation (default: ON)
--no-webcam         Force synthetic 3D graphics camera feed in simulation
--camera-id INT     OpenCV camera index (default: 0)
--gps-port PORT     Serial port for GPS (default: COM3 / /dev/ttyUSB0)
--mmwave-port PORT  Serial port for mm-Wave radar (default: COM4 / /dev/ttyUSB1)
--thermal-port PORT Serial port for Thermal camera (default: COM5 / /dev/ttyUSB2)
--baud-gps INT      GPS baud rate (default: 9600)
--baud-mmwave INT   mm-Wave baud rate (default: 115200)
--db PATH           SQLite database path (default: drone_data.db)
```

## Live HUD & Simulation View

When running with `--show-feed` (default):
- **Hardware Mode**: Shows the live camera feed with real-time HUD telemetry overlays.
- **Simulation Mode**: Renders a dynamic first-person 3D drone camera view with an artificial horizon pitch ladder, obstacle tracking boxes, GPS/Radar telemetry badges, and a Thermal camera Picture-in-Picture (PiP) mini-map.


## Dashboard Controls

| Key | Action |
|-----|--------|
| `q` | Quit and save session |
| `e` | Export current session to CSV |
| `p` | Pause / resume recording |
| `a` | Ask the offline AI about the active recording session |

## Offline AI assistant

Press `a` while the collector is running to ask a natural-language question about
the active session. The assistant uses the local SQLite database (session summary
and the most recent readings) as its only source of facts; sensor data is not sent
to any cloud service.

It requires a locally running Ollama server and a downloaded local model. By
default the collector uses `phi4-mini`; select another installed model with
`--ai-model MODEL`.

## CSV Export

Exported files are named `export_YYYYMMDD_HHMMSS.csv` and contain all sensor readings for the current session, merged by timestamp.
